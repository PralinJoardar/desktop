var object_fetchdata = localStorage.getItem("fdata");

var fetchdata = JSON.parse(object_fetchdata);

document.getElementById('fname').innerHTML = fetchdata.fname;
document.getElementById('lname').innerHTML = fetchdata.lname;
document.getElementById('email').innerHTML = fetchdata.email;
document.getElementById('dob').innerHTML = fetchdata.dob;
document.getElementById('cnumber').innerHTML = fetchdata.cnumber;
document.getElementById('city').innerHTML = fetchdata.city;