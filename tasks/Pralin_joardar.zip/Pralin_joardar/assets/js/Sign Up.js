/** Sign up Form validation */
function signup_validateForm() {
    var a = document.forms["f1"]["firstName"].value;
    var b = document.forms["f1"]["lastName"].value;
    var c = document.forms["f1"]["contactNumber"].value;
    var d = document.forms["f1"]["inputDate"].value;
    var e = document.forms["f1"]["city"].value;


    var dob = new Date(d);
    var minage = 18;
    var month_diff = Date.now() - dob.getTime();
    var age_dt = new Date(month_diff);
    var year = age_dt.getUTCFullYear();
    var age = Math.abs(year - 1970);

    if (age < minage) {
        alert("below 18 years");
        return false;
    }

    if (!a.match(/^[A-Za-z\s]{1,}[\.]{0,1}[A-Za-z\s]{0,}$/)) {
        alert("Please provide valid input in first name");
        return false;
    }
    if (!b.match(/^[A-Za-z\s]{1,}[\.]{0,1}[A-Za-z\s]{0,}$/)) {
        alert("Please provide valid input in last name");
        return false;
    }
    if (!c.match(/(?<!\d)\d{10}(?!\d)/)) {
        alert("Please provide valid contact number");
        return false;
    }
    if (!e.match(/^[A-Za-z\s]{1,}[\.]{0,1}[A-Za-z\s]{0,}$/)) {
        alert("Please provide valid input in city");
        return false;
    }


    /** Local Storage */
    var fname = document.getElementById('firstName').value;

    var lname = document.getElementById('lastName').value;

    var email = document.getElementById('inputEmail').value;

    var dob = document.getElementById('inputDate').value;

    var cnumber = document.getElementById('contactNumber').value;

    var city = document.getElementById('city').value;


    var data = {
        fname,
        lname,
        email,
        dob,
        cnumber,
        city
    };
    var fdata = JSON.stringify(data);

    localStorage.setItem("fdata", fdata);

}